<?php include("header.php");?>
<?php include("extra.php");?>
<div id="wrapper">
	<div id="content">

<h2>Welcome to Digital Video Frame</h2>

<p>This is a web (Flash)-based video telephony and photo frame software. See <a href="about.php">this page</a> for details on how to use it. For a quick start, click on
the animated frame above, and press enter key (or double click) to show the main menu.
You can use the five keys on the keyboard, the enter key and the four arrow keys, to control the frame. The arrow keys are for navigation, and enter key for selection.
</p>

<h3>Features</h3>
<ol>
<li>Real-time video and audio telephony</li>
<li>Presence indication of your friends</li>
<li>Web-based configuration</li>
<li>Configurable photo and video slide show</li>
<li>Recording and playback of video and audio messages</li>
</ol>

	</div>
</div>
<?php include("sidebar1.php");?>
	
<?php include("footer.php");?>
