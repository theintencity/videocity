<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">

<head profile="http://gmpg.org/xfn/11">
<meta http-equiv="Content-Type" content="html/plain" />
<title>Digital Video Frame</title>
<meta name="keywords" content="Video Frame, Video Telephony" />
<link rel="stylesheet" href="style.css" type="text/css" media="screen" />
<script src="AC_OETags.js" language="javascript"></script>
</head>

<body>
<div id="container">
	<div id="header">
		<h1>Digital Video Frame</h1>
		<div class="description">Web video telephony and photo frame</div>
		<div id="nav">
		<ul id="navbar">
		<li ><a href="index.php">Home</a></li>
		<li class="page_item"><a href="about.php">About</a></li>
		</ul></div>

	</div>
