	
	<div id="footer">
		<p>
		&copy; 2007, <i>Kundan Singh and Sanjay Chouksey</i><br/>All rights reserved.
		</p>
	</div>
</div> 
</body>
</html>