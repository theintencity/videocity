<div id="navigation">

<h2>Download</h2>
	<ul>
	<li><strong>Windows XP/Vista:</strong> <a href="/download/39peers.exe">download</a> (6.5MB).</li>
	<li><strong>Mac OS X:</strong> coming soon</li>
        <!--
	<li><strong>Manual install:</strong> Download and install <a href="http://www.python.org/" 	target="_blank">Python version 2.5</a> or higher. Then download this agent and run it.</li>
        -->
	</ul>


<h2>Links</h2>
	<ul>
	<li><strong><a href="">Flash-based video</a></strong></li>
	</ul>		
</div>