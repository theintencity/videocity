<div id="extra">
   <table cellspacing="0" cellpadding="0">
     <tr><td width="485" height="285">
	<div>
	<script language="JavaScript" type="text/javascript">
	<!--
	var hasRequestedVersion = DetectFlashVer(9, 0, 28);
	if (!hasRequestedVersion) {
	    var alternateContent = 'This content requires the Adobe Flash Player 9.0.28 or higher. '
	   	+ '<a href=http://www.adobe.com/go/getflash/>Get Flash</a>';
	    document.write(alternateContent);  // insert non-flash content
	}
	// -->
	</script>

	<object classid="clsid:d27cdb6e-ae6d-11cf-96b8-444553540000" codebase="http://download.macromedia.com/pub/shockwave/cabs/flash/swflash.cab" width="470" height="285" id="videoframe" align="middle">
	<param name="allowScriptAccess" value="sameDomain" />
	<param name="allowFullScreen" value="true" />
	<param name="movie" value="videoframe.swf" />
	<param name="quality" value="high" />
	<param name="bgcolor" value="#ffffff" />	
	<embed src="videoframe.swf" loop="false" quality="high" bgcolor="#ffffff" 
		width="470" height="285" name="videoframe" align="middle" allowScriptAccess="sameDomain" 
		allowFullScreen="true" type="application/x-shockwave-flash"
		pluginspage="http://www.macromedia.com/go/getflashplayer" />
	</object>
	</div>

     </td><td>

	<div id="extra-sidebar">
	<h2>Share Live Video!</h2>
	<ul>
		<li>Talk to your friends live using web-based audio and video technology</li>
		<li>Or play a slideshow of your favorite photos and videos</li>
		<li>Or use this on a digital photo frame hardware to build a video frame device</li>
	</ul>
	</div>
     </td></tr>
   </table>
</div>