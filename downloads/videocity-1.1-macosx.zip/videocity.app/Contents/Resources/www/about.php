<?php include("header.php");?>

<div id="wrapper">
	<div id="content">

<h2>About Digital Video Frame</h2>

<p>
We all have some technologically challenged relatives, who would like to keep in touch with us. Digital photo frames were invented to electronically share pictures that display multiple photos in a slideshow format, and connect to the Internet to download these photos. Similarly, digital video frames can be designed that can be used to not only share photos and videos but also to do real-time video call with the person. This page shows a digital video frame software and how it works. 
</p>

<p>
There are two main components: the web based viewer and the back-end agent. The web page embeds a viewer, whereas the agent should be installed separately. The viewer is Flash-based .swf file written in ActionScript 3, and agent is a Python application. The viewer controls the main display, shows the slideshow, does video call and provides user friendly menus. The viewer captures and plays audio and video. The agent controls the backend processing such as talking to a VoIP server to register and discover each other, and exchange media on a end-to-end pipe.
</p>

<p>
To see the demonstration of the video frame software on a Windows XP machine, first download the <a href="agent.exe">agent</a>, install it and run it. Then login as these two users: <a href="user1.html" target="_blank">user 1</a> and <a href="user2.html" target="_blank">user 2</a> on two separate browser instances. If the two users are logged in from two different machines, you will need to run the agent on both. 
</p>

<p>
If the frame does not show any picture then it probably did not get the config file. If the frame disables itself (i.e., color becomes faded instead of bright), then the connection to the agent failed or SIP registration failed. Please check that the agent is running and that the account shown in the config file is valid.
</p>

<p>
Once the frame starts, you can click anywhere on the frame to set the focus there. Then, you can use the five keys (which includes the enter/return key and the four up, down, left, right, arrow keys) on your keyboard when the frame has the focus to control. The default state is to display the photos and videos in a slideshow. When you press the enter key in the default state, it enters the main configuration state which shows the selected icon for changing the settings, and vertical list of your friends and horizontal list of your photos and videos. You can press enter again to select the settings, or press up or down arrow key to browse through your friends list, or press left or right arrow to browse through your photos. You can press the enter key to select the friend and to place a video call to that friend. The main configuration state timesout after no activity of few seconds and goes back to the default state. When in the talking or call state you can press enter to get the menu for further options. You can press the enter key to select a menu option or select Exit option to quit the menu. For the demonstration shown between User 1 and User 2, the first friend (the one that gets selected after pressing enter followed by down arrow) is the other user you can call.
</p>

<p>Each of these users' video frame is configured using a config file that you can view for <a href="config.xml">user 1</a> and <a href="config2.xml">user 2</a>. These config files are loaded from the web.
</p>

<p>
You can start the viewer in a kiosk mode so that it occupies the full screen giving a better view as a Video Frame as follows. Right click and save the link location of the <a href="frameweb.swf">swf</a> file. Suppose the link location is "http://localhost/examples/frameweb/frameweb.swf". Then use your Internet Explorer with -k option to open the swf file. In most Windows XP installation, this can be done as follows:
<pre>"C:\Program Files\Internet Explorer\iexplore.exe" -k http://localhost/examples/frameweb/frameweb.swf</pre>
This default run uses the config file of user 1, so make sure you do not open user 1's page in the browser.
</p>

<p>
Note that the agent does not use SIP if multiple communicating viewers are connected on the same agent, on the same machine. To force and test the SIP call, either you can use two different machines and hence run two different instances of the agent, or follow the following instructions to run two instances on the same machine. Run the first agent as it is. Then on the same machine run the second instance of the agent with the command line option -p 1936. This will start the second agent on port 1936 instead of using the default port of 1935 of the first instance. Now start <a href="user1.html" target="_blank">user 1</a> as before, but use this alternate link to <a href="user2_alt.html" target="_blank">user 2</a>. The difference is in the html file which supplies a different agent URL to the frame object.
</p>


	</div>
</div>

<?php include("sidebar1.php");?>
<?php include("footer.php");?>
